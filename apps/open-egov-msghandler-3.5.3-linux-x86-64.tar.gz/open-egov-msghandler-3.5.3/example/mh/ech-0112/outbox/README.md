A sample sedex outbox
