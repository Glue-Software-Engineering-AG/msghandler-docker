A sample sedex inbox
