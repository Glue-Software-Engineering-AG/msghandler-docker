A sample eSchKG (native) signing outbox
